package com.example.henryforce.navexample;

/**
 * Created by Henryforce on 7/10/15.
 */
public class Const {
    static final String TAG = "SPP_TERMINAL";
}
